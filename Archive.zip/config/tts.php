<?php
return [
    // 'app_secret' => '2ed467c9ddfc31d7638e47c61c0188eb5f49d3f2',
    // 'app_key' => '6etidnmfjg6rb',
    'app_secret' => 'f4e54d5a9789b5b7cadec5e0e5dab8ad1782bbec',
    'app_key' => '6f06lb90u4oc4',
    'base_url'=>'https://open-api.tiktokglobalshop.com'
];
