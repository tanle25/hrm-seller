<div>
    <div class="bg-white rounded-lg shadow-sm p-4">
        <div class="flex items-center">
            <div class="w-10">1</div>
            
            <?php $__currentLoopData = itemCount($order['line_items']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="flex-1">
                    <?php $__currentLoopData = $item['skus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex-1">
                            <div class="items-center gap-3">
                                <img src="<?php echo e($sku['sku_image']); ?>" class="w-12 h-12 object-cover rounded"
                                    alt="Product">
                                <div>
                                    <div class="font-medium"><?php echo e($item['product_name']); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo e($item['product_id']); ?></div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class=" w-52 flex items-center gap-2">
                <span><?php echo e($order['id']); ?></span>
                <button class="hover:bg-gray-100 p-1 rounded">
                    <svg class="w-4 h-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                </button>
            </div>

            <div class="w-40">
                <div>J&T Express</div>
                <button
                    class="px-3 py-1 mt-1 text-sm text-gray-600 border border-gray-300 rounded-md hover:bg-gray-50">
                    Chuẩn bị hàng
                </button>
            </div>

            <div class="w-32 text-green-600">450,000</div>

            <div class=" w-56 flex items-center gap-2">
                <svg class="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                <span>TRINH BA HAO ...47N4CVGE2E</span>
            </div>
            <div class="w-40 flex items-center gap-2">
                <span>18:00 - 12/1/2024</span>
            </div>
            <div class="w-40 flex items-center gap-2">

                <span>18:00 - 15/1/2024</span>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/tanle/Desktop/laravel/hrm-chat/resources/views/components/order-item.blade.php ENDPATH**/ ?>