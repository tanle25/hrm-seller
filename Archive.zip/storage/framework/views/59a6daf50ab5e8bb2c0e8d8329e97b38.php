<?php $__env->startSection('content'); ?>
    <section class="flex-1 p-4">
        <!-- Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="p-4 bg-white rounded-md shadow-md">
                <h2 class="text-sm text-gray-500">Total Users</h2>
                <p class="text-xl font-semibold">1,234</p>
            </div>
            <div class="p-4 bg-white rounded-md shadow-md">
                <h2 class="text-sm text-gray-500">Total Sales</h2>
                <p class="text-xl font-semibold">$45,678</p>
            </div>
            <div class="p-4 bg-white rounded-md shadow-md">
                <h2 class="text-sm text-gray-500">Orders Pending</h2>
                <p class="text-xl font-semibold">56</p>
            </div>
        </div>

        <!-- Data Table -->
        <div class="p-4 flex">
            <form id="shipping-form" action="<?php echo e(url('shipping-package')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded">
                    Xác nhận đơn hàng
                </button>
            </form>
            <form id="print-form" action="<?php echo e(url('get-shipping-document')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded">
                    In đơn hàng
                </button>
            </form>
        </div>

        <div class="w-full space-y-4 p-4">
            <!-- Header -->
            <div class="flex items-center px-4 py-3 bg-gray-50 rounded-lg">
                <div class="w-10"></div>
                <div class="flex-1">Mặt Hàng</div>
                <div class="w-52">Mã Đơn Hàng</div>
                <div class="w-40">Mã Vận Đơn</div>
                <div class="w-32">Doanh Thu</div>
                <div class="w-56">Nguồn</div>
                <div class="w-40">Tạo Lúc</div>
                <div class="w-40">Quá Hạn</div>
            </div>

            <!-- Card 1 -->
            <?php $__currentLoopData = $orders['orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php echo $__env->make('admin.components.order.order-item-single',['index'=>$index, 'order'=>$order], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- Card 2 -->


            <!-- Thêm Card 3 tương tự -->

        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>


<script>
   function toggleDetails(orderId) {
  const details = document.getElementById(`details-${orderId}`);
  if (details.classList.contains("hidden")) {
    details.classList.remove("hidden");
  } else {
    details.classList.add("hidden");
  }
}

</script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tanle/Desktop/laravel/hrm-chat/resources/views/admin/order.blade.php ENDPATH**/ ?>