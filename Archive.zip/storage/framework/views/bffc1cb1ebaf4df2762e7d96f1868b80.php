<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Template</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    /* Smooth transition for sidebar */
    aside {
      transition: transform 0.3s ease-in-out;
    }
  </style>
</head>
<body class="bg-gray-100">
  <!-- Wrapper -->
  <div class="flex h-screen">
    <!-- Sidebar -->
    <aside id="sidebar" class="w-64 bg-gray-800 text-white flex flex-col">
      <div class="px-4 py-5 text-center text-lg font-bold border-b border-gray-700">
        Admin Panel
      </div>
      <nav class="flex-1 px-4 py-4 space-y-2">
        <a href="#" class="block px-3 py-2 rounded-md hover:bg-gray-700">
          Dashboard
        </a>
        <a href="#" class="block px-3 py-2 rounded-md hover:bg-gray-700">
          Users
        </a>
        <a href="#" class="block px-3 py-2 rounded-md hover:bg-gray-700">
          Orders
        </a>
        <a href="#" class="block px-3 py-2 rounded-md hover:bg-gray-700">
          Products
        </a>
        <a href="#" class="block px-3 py-2 rounded-md hover:bg-gray-700">
          Settings
        </a>
      </nav>
      <div class="px-4 py-4 border-t border-gray-700">
        <button class="w-full px-3 py-2 bg-red-600 rounded-md hover:bg-red-700">
          Logout
        </button>
      </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 flex flex-col">
      <!-- Header -->
      <header class="bg-white shadow-md px-4 py-3 flex justify-between items-center">
        <div class="flex items-center space-x-4">
          <button id="toggleSidebar" class="text-gray-800 md:hidden">
            ☰
          </button>
          <h1 class="text-lg font-semibold">Dashboard</h1>
        </div>
        <div class="flex items-center space-x-4">
          <input
            type="text"
            placeholder="Search..."
            class="border rounded-md px-3 py-2 text-sm"
          />
          <button class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
            Add New
          </button>
        </div>
      </header>

      <!-- Content -->
      <section class="flex-1 p-4">
        <!-- Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div class="p-4 bg-white rounded-md shadow-md">
            <h2 class="text-sm text-gray-500">Total Users</h2>
            <p class="text-xl font-semibold">1,234</p>
          </div>
          <div class="p-4 bg-white rounded-md shadow-md">
            <h2 class="text-sm text-gray-500">Total Sales</h2>
            <p class="text-xl font-semibold">$45,678</p>
          </div>
          <div class="p-4 bg-white rounded-md shadow-md">
            <h2 class="text-sm text-gray-500">Orders Pending</h2>
            <p class="text-xl font-semibold">56</p>
          </div>
        </div>

        <!-- Data Table -->
        <div class="mt-6">
          <h2 class="text-lg font-semibold mb-4">Recent Orders</h2>
          <div class="bg-white rounded-md shadow-md overflow-hidden">
            <table class="w-full">
              <thead class="bg-gray-100 border-b">
                <tr>
                  <th class="text-left px-4 py-2">Order ID</th>
                  <th class="text-left px-4 py-2">Customer</th>
                  <th class="text-left px-4 py-2">Total</th>
                  <th class="text-left px-4 py-2">Status</th>
                  <th class="text-left px-4 py-2">Date</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="px-4 py-2">#12345</td>
                  <td class="px-4 py-2">John Doe</td>
                  <td class="px-4 py-2">$120.00</td>
                  <td class="px-4 py-2">
                    <span class="text-green-600">Completed</span>
                  </td>
                  <td class="px-4 py-2">2025-01-09</td>
                </tr>
                <tr class="bg-gray-50">
                  <td class="px-4 py-2">#12346</td>
                  <td class="px-4 py-2">Jane Smith</td>
                  <td class="px-4 py-2">$75.00</td>
                  <td class="px-4 py-2">
                    <span class="text-yellow-600">Pending</span>
                  </td>
                  <td class="px-4 py-2">2025-01-08</td>
                </tr>
                <tr>
                  <td class="px-4 py-2">#12347</td>
                  <td class="px-4 py-2">Bob Johnson</td>
                  <td class="px-4 py-2">$210.00</td>
                  <td class="px-4 py-2">
                    <span class="text-red-600">Cancelled</span>
                  </td>
                  <td class="px-4 py-2">2025-01-07</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </main>
  </div>

  <script>
    const toggleButton = document.querySelector('#toggleSidebar');
    const sidebar = document.querySelector('#sidebar');

    toggleButton.addEventListener('click', () => {
      sidebar.classList.toggle('-translate-x-full');
    });

    // Initialize sidebar state for small screens
    if (window.innerWidth < 768) {
      sidebar.classList.add('-translate-x-full');
    }

    window.addEventListener('resize', () => {
      if (window.innerWidth >= 768) {
        sidebar.classList.remove('-translate-x-full');
      }
    });
  </script>
</body>
</html>
<?php /**PATH /Users/tanle/Desktop/laravel/hrm-chat/resources/views/admin.blade.php ENDPATH**/ ?>